#!/usr/bin/env python3
import sys
import boto3
s3 = boto3.resource("s3")
bucket_name = sys.argv[1]
object_name = sys.argv[2]
try:
    response = s3.Object(bucket_name, object_name).put(Body=open(object_name, 'rb'))
    #hard coding bucket and object details
    #https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html#objectacl
    object_acl = s3.ObjectAcl('11713929-imgbucket','image.jpg')
    #set permission to publicly-readable
    response = object_acl.put(ACL='public-read')
    print (response)
except Exception as error:
    print (error)
