#!/usr/bin/env python3
import boto3
import subprocess
import sys
import time
ec2_resource = boto3.resource('ec2')


#create instance
new_instance = ec2_resource.create_instances(
                                    ImageId='ami-0d712b3e6e1f798ef',
                                    MinCount=1,
                                    MaxCount=1,
                                    InstanceType='t2.nano',
                                    #hardcoded security group
                                    SecurityGroups=['Week3ssh',],
                                    SecurityGroupIds=['sg-0dcf40d3ac12c872b',],
                                    #adding userdata with bash script
                                    UserData='''
						#!/bin/bash
						yum install httpd -y 
						systemctl enable httpd 
						systemctl start httpd
					     ''',
                                    TagSpecifications=[
								{
								    'ResourceType': 'instance',
								    'Tags': [
									{
									    'Key': 'Name',
									    'Value': 'project'
									},
								    ]
								},
						      ],   
                                    KeyName='dev_ops'
                                        )

 

#print instance created
print('The following instance has been created')
print(new_instance[0].id)
print('added userdata')
print('---------------------------------------------')
print('reloading instance')

for instance_id in sys.argv[0:]:
	     instance=ec2_resource.Instance(id=new_instance[0].id)
	     response=instance.reload()
	     #waiter for instance reload
	     print('applying waiter')
	     instance.wait_until_running()
	     print('instance is running after reload')                
                                        	





 
#create instance list
#new_instances=[]


#connect with ssh


for instance_id in sys.argv[0:]:
	     instance=ec2_resource.Instance(id=new_instance[0].id)
	     response=instance.public_ip_address
	     print('Public IP ADDRESS: '+str(response))
	     print('applying waiter')
	     instance.wait_until_running()
	     cmd1 = "ssh -o StrictHostKeyChecking=no -i dev_ops.pem ec2-user@" + str(instance.public_ip_address) + " 'sudo yum -y install httpd'"
	     print('delay of 25 seconds... sorry for the wait')
	     time.sleep(25)
	     response=subprocess.run(cmd1, shell=True)
	     
	     print(response)
	     print('connected with ssh')



#create bucket

print('creating bucket')        
subprocess.run(['./create_bucket.py'], shell=True)
#download image
cmd2="curl -O http://devops.witdemo.net/image.jpg"
subprocess.run(cmd2,shell=True)
#put image in bucket
cmd3="./put_bucket.py 11713929-imgbucket image.jpg"
subprocess.run(cmd3,shell=True)

	     
#add metada of instance to index.html
for instance_id in sys.argv[0:]:
	     instance=ec2_resource.Instance(id=new_instance[0].id)
	     #create index.html
	     cmd0="echo '<html>' > index.html"
	     response=subprocess.run(cmd0, shell=True)
	     
	     #append local-ipv4 of instance
	     print(' adding LOCAL IP4 to index.html')
	     #send to html file
	     cmd8_02="echo '<br>LOCAL IPV4' >> index.html "
	     response=subprocess.run(cmd8_02, shell=True)
	     cmd8_03="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" curl http://169.254.169.254/latest/meta-data/local-ipv4  >> index.html"
	     response=subprocess.run(cmd8_03, shell=True)
	     
	     #append availability zone of instance to index.html
	     print('adding security groups to index.html ')
	     cmd9_01="echo '<br>Security Groups: ' >> index.html "
	     response=subprocess.run(cmd9_01, shell=True)
	     cmd9_02="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" curl http://169.254.169.254/latest/meta-data/security-groups>> index.html"
	     response=subprocess.run(cmd9_02, shell=True)	     
#adding   image
	     #append to index.html href of bucket containing image
	     cmd5="echo '<img src=https://s3-eu-west-1.amazonaws.com/11713929-imgbucket/image.jpg>' >> index.html"
	    
	     response=subprocess.run(cmd5,shell=True)
	     
	     #put index.html in ec2 instance
	     cmd6= "scp -i dev_ops.pem index.html  ec2-user@"+str(instance.public_ip_address)+":."
	
	     response=subprocess.run(cmd6,shell=True)
	     
	     #copy to /var/www/html
	     cmd7="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" 'sudo cp index.html /var/www/html '"
	 
	     response=subprocess.run(cmd7,shell=True)
#monitoring
	     
for instance_id in sys.argv[0:]:
	     instance=ec2_resource.Instance(id=new_instance[0].id)	
	     #scp monitor.sh to instance
	     cmd10= "scp -i dev_ops.pem monitor.sh  ec2-user@"+str(instance.public_ip_address)+":."
	     response=subprocess.run(cmd10,shell=True)
	     #give monitor.sh permissions
	     cmd11="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" 'chmod 700 monitor.sh' "
	     response=subprocess.run(cmd11,shell=True)
	     #run monitor.sh
	     print('running monitor.sh')
	     cmd12="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" './monitor.sh' "
	     response= subprocess.run(cmd12, shell=True)
	     

for instance_id in sys.argv[0:]:
	     instance=ec2_resource.Instance(id=new_instance[0].id)
	     #bash script to use instance cpu
	     #print('running bash scripto force CPU utilisation up to 100%')
	     #cmd13="ssh -i dev_ops.pem ec2-user@"+str(instance.public_ip_address)+" ' while true; do x=0; done '"		     
	     r#esponse=subprocess.run(cmd13, shell=True)
	     print('applying cloudwatch python script')
	     cmd14="./cloudwatch_utils.py"
	     response=subprocess.run(cmd14, shell=True)
	     print('thank you for using my program... bye')
	     
	     
